# SPORTZONE — Entrega 2: três telas em Angular 17

Projeto Integrador II · Grupo 6 · Centro Universitário Senac (ADS) · Prof. Dr. Eliseu Lemes da Silva

## O que foi pedido pelo professor e onde está

| Módulo exigido | Tela | Rota | Pasta no projeto |
|---|---|---|---|
| Módulo principal da aplicação | Tela principal (início, categorias, busca, produtos, carrinho lateral) | `/` | `src/app/app.module.ts` + `src/app/pages/home/` + `src/app/shared/` |
| Módulo de login | Login | `/login` | `src/app/login/` |
| Módulo de registro (cadastro) | Cadastro de usuário | `/registro` | `src/app/registro/` |

Versão: **Angular 17** com **NgModules** (`--no-standalone`), TypeScript, HTML e CSS. Os módulos de login e registro são carregados sob demanda (lazy loading).

## Como executar no Windows com o VS Code

1. Instale o **Node.js 18.13+ ou 20 LTS** (https://nodejs.org). Node 22 também funciona, mas o Angular 17 pode exibir um aviso de "versão não suportada"; se houver problemas, use a versão 20 LTS.
2. Abra o **VS Code** → *File → Open Folder…* → selecione a pasta `sportzone` (a que contém `package.json`).
3. Abra o terminal integrado (*Terminal → New Terminal*) e confira as versões:
   ```
   node -v
   npm -v
   ```
4. Instale as dependências (apenas na primeira vez; leva alguns minutos):
   ```
   npm install
   ```
   O Angular CLI já está nas dependências do projeto; não precisa instalar globalmente. Use sempre `npm start` ou `npx ng ...`.
5. Inicie o servidor:
   ```
   npm start
   ```
6. Abra o navegador em **http://localhost:4200**. Para parar, use `Ctrl + C` no terminal.

Build de produção (opcional): `npm run build` (gera a pasta `dist/`).

### Erros comuns
- **`ng` não é reconhecido**: use `npm start` (ou `npx ng serve`).
- **Porta 4200 em uso**: `npx ng serve --port 4300`.
- **Erros após copiar arquivos**: apague `node_modules` e rode `npm install` novamente.
- **Script desabilitado no PowerShell** (`npm.ps1 ... UnauthorizedAccess`): rode `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned` ou use o terminal *Prompt de Comando*.

## Como testar as funções

- **Tela principal**: filtre por categoria, pesquise no cabeçalho, adicione produtos ao carrinho (o ícone do carrinho abre o painel: aumentar/diminuir/remover/limpar). "Mochila" aparece como *Esgotado*.
- **Cadastro** (`/registro`): campos obrigatórios, nome e sobrenome, e-mail válido, senha com 8+ caracteres com letras e números, confirmação igual e aceite do aviso. Ao concluir, redireciona ao login.
- **Login** (`/login`): use a conta cadastrada ou o botão *Preencher conta de demonstração* (`demo@sportzone.com` / `Demo@1234`). Depois do login, o cabeçalho mostra "Olá, <nome>" e o botão *Sair*.

## Estrutura de arquivos

```
src/
├─ index.html                       página base
├─ styles.css                       identidade visual global (cores, botões, formulários, layout de login/cadastro)
├─ assets/img/                      logotipo e ilustrações dos produtos (SVG originais)
└─ app/
   ├─ app.module.ts                 MÓDULO PRINCIPAL
   ├─ app-routing.module.ts         rotas (/, /login, /registro; os dois últimos em lazy loading)
   ├─ app.component.ts              casca: cabeçalho + conteúdo + rodapé
   ├─ core/models/produto.ts        interfaces (Produto, ItemCarrinho, Usuario, Sessao)
   ├─ core/services/produtos.service.ts   lista de produtos de demonstração
   ├─ core/services/carrinho.service.ts   carrinho (em memória + localStorage)
   ├─ core/services/auth.service.ts       login/cadastro demonstrativos (localStorage)
   ├─ shared/header/                cabeçalho, busca, menu, carrinho lateral (ts/html/css)
   ├─ shared/footer/                rodapé (ts/html/css)
   ├─ pages/home/                   TELA PRINCIPAL (ts/html/css)
   ├─ login/                        MÓDULO DE LOGIN (login.module.ts + componente ts/html/css)
   └─ registro/                     MÓDULO DE REGISTRO (registro.module.ts + componente ts/html/css)
```

## Limitações (importante para a apresentação)

- **Não há back-end nem banco de dados nesta etapa.** Produtos são dados fixos no código; usuários e carrinho ficam no `localStorage` do navegador.
- O login/cadastro é **demonstrativo e não é seguro**: a senha é guardada apenas como hash SHA-256 no navegador. Será substituído por autenticação no servidor.
- O botão "Finalizar compra" está desabilitado (checkout fica para etapas futuras).
- Catálogo completo, detalhes do produto, carrinho em página própria e área administrativa constam no **protótipo visual (Entrega 3)**, mas **não** fazem parte desta implementação de três telas.
