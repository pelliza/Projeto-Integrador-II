import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { RegistroComponent } from './registro.component';

const routes: Routes = [{ path: '', component: RegistroComponent, title: 'SPORTZONE | Criar conta' }];

/** MÓDULO DE REGISTRO (CADASTRO) — carregado sob demanda na rota /registro. */
@NgModule({
  declarations: [RegistroComponent],
  imports: [CommonModule, ReactiveFormsModule, RouterModule.forChild(routes)]
})
export class RegistroModule {}
