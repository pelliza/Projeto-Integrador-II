import { Component } from '@angular/core';
import { AbstractControl, FormBuilder, ValidationErrors, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../core/services/auth.service';

/** Exige nome e sobrenome (ao menos duas palavras). */
function nomeCompleto(c: AbstractControl): ValidationErrors | null {
  const partes = String(c.value ?? '').trim().split(/\s+/).filter(Boolean);
  return partes.length >= 2 ? null : { nomeCompleto: true };
}

/** Exige ao menos uma letra e um número. */
function senhaForte(c: AbstractControl): ValidationErrors | null {
  const v = String(c.value ?? '');
  if (!v) { return null; }
  return /[A-Za-z]/.test(v) && /\d/.test(v) ? null : { senhaFraca: true };
}

/** Confere se senha e confirmação são iguais. */
function senhasIguais(g: AbstractControl): ValidationErrors | null {
  return g.get('senha')?.value === g.get('confirmacao')?.value ? null : { senhasDiferentes: true };
}

@Component({
  selector: 'app-registro',
  templateUrl: './registro.component.html',
  styleUrls: ['./registro.component.css']
})
export class RegistroComponent {
  form = this.fb.nonNullable.group({
    nome: ['', [Validators.required, Validators.minLength(5), nomeCompleto]],
    email: ['', [Validators.required, Validators.email]],
    senha: ['', [Validators.required, Validators.minLength(8), senhaForte]],
    confirmacao: ['', [Validators.required]],
    termos: [false, [Validators.requiredTrue]]
  }, { validators: senhasIguais });

  mostrarSenha = false;
  enviando = false;
  erro = '';
  sucesso = false;

  constructor(private fb: FormBuilder, private auth: AuthService, private router: Router) {}

  get nome() { return this.form.controls.nome; }
  get email() { return this.form.controls.email; }
  get senha() { return this.form.controls.senha; }
  get confirmacao() { return this.form.controls.confirmacao; }
  get termos() { return this.form.controls.termos; }

  invalido(c: { invalid: boolean; touched: boolean }): boolean {
    return c.invalid && c.touched;
  }

  get senhasDiferem(): boolean {
    return this.form.hasError('senhasDiferentes') && this.confirmacao.touched && this.confirmacao.value !== '';
  }

  async cadastrar(): Promise<void> {
    this.erro = '';
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    this.enviando = true;
    const { nome, email, senha } = this.form.getRawValue();
    const r = await this.auth.cadastrar(nome, email, senha);
    this.enviando = false;
    if (!r.ok) {
      this.erro = r.erro ?? 'Não foi possível concluir o cadastro.';
      return;
    }
    this.sucesso = true;
    setTimeout(() => this.router.navigate(['/login'], { queryParams: { cadastro: 'ok', email: email.trim().toLowerCase() } }), 1400);
  }
}
