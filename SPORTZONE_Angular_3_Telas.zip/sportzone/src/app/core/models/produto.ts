export type Categoria = 'Camisas' | 'Chuteiras' | 'Bolas' | 'Goleiro' | 'Acessórios';

export interface Produto {
  id: number;
  nome: string;
  categoria: Categoria;
  preco: number;
  estoque: number;
  descricao: string;
  imagem: string;
}

export interface ItemCarrinho {
  produto: Produto;
  quantidade: number;
}

export interface Usuario {
  nome: string;
  email: string;
  senhaHash: string;
}

export interface Sessao {
  nome: string;
  email: string;
}
