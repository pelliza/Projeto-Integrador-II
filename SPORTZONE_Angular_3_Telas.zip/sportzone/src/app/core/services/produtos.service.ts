import { Injectable } from '@angular/core';
import { Categoria, Produto } from '../models/produto';

/** Dados de demonstração (ainda não existe back-end nem banco de dados). */
@Injectable({ providedIn: 'root' })
export class ProdutosService {
  readonly categorias: Categoria[] = ['Camisas', 'Chuteiras', 'Bolas', 'Goleiro', 'Acessórios'];

  private readonly produtos: Produto[] = [
    { id: 1, nome: 'Camisa Titular Verde 10', categoria: 'Camisas', preco: 249.9, estoque: 14, descricao: 'Tecido leve com secagem rápida.', imagem: 'assets/img/camisa-titular.svg' },
    { id: 2, nome: 'Camisa Treino Black 07', categoria: 'Camisas', preco: 179.9, estoque: 22, descricao: 'Ideal para treinos e peladas.', imagem: 'assets/img/camisa-treino.svg' },
    { id: 3, nome: 'Chuteira de Campo Velocity', categoria: 'Chuteiras', preco: 459.9, estoque: 9, descricao: 'Travas para gramado natural.', imagem: 'assets/img/chuteira-campo.svg' },
    { id: 4, nome: 'Chuteira Society Street', categoria: 'Chuteiras', preco: 329.9, estoque: 12, descricao: 'Solado para grama sintética.', imagem: 'assets/img/chuteira-society.svg' },
    { id: 5, nome: 'Bola de Campo Pro', categoria: 'Bolas', preco: 189.9, estoque: 30, descricao: 'Costura reforçada, tamanho oficial.', imagem: 'assets/img/bola.svg' },
    { id: 6, nome: 'Luvas de Goleiro Guard', categoria: 'Goleiro', preco: 219.9, estoque: 6, descricao: 'Palma com alta aderência.', imagem: 'assets/img/luvas-goleiro.svg' },
    { id: 7, nome: 'Caneleira Shield', categoria: 'Acessórios', preco: 59.9, estoque: 40, descricao: 'Proteção leve e anatômica.', imagem: 'assets/img/caneleira.svg' },
    { id: 8, nome: 'Mochila Esportiva SZ', categoria: 'Acessórios', preco: 139.9, estoque: 0, descricao: 'Compartimento para chuteiras.', imagem: 'assets/img/mochila.svg' },
    { id: 9, nome: 'Meião Listrado Pro', categoria: 'Acessórios', preco: 39.9, estoque: 55, descricao: 'Cano alto com reforço no pé.', imagem: 'assets/img/meiao.svg' }
  ];

  listar(categoria: string | null, busca: string | null): Produto[] {
    const termo = (busca ?? '').trim().toLowerCase();
    return this.produtos.filter(p =>
      (!categoria || p.categoria === categoria) &&
      (!termo || (p.nome + ' ' + p.categoria + ' ' + p.descricao).toLowerCase().includes(termo))
    );
  }
}
