import { Injectable } from '@angular/core';
import { BehaviorSubject, map } from 'rxjs';
import { ItemCarrinho, Produto } from '../models/produto';

const CHAVE = 'sz_carrinho';

/** Carrinho local (somente no navegador). Guarda os itens em localStorage para demonstração. */
@Injectable({ providedIn: 'root' })
export class CarrinhoService {
  private readonly itens$ = new BehaviorSubject<ItemCarrinho[]>(this.carregar());

  readonly itens = this.itens$.asObservable();
  readonly quantidadeTotal = this.itens$.pipe(map(l => l.reduce((s, i) => s + i.quantidade, 0)));
  readonly valorTotal = this.itens$.pipe(map(l => l.reduce((s, i) => s + i.quantidade * i.produto.preco, 0)));

  adicionar(produto: Produto): boolean {
    const lista = [...this.itens$.value];
    const existente = lista.find(i => i.produto.id === produto.id);
    if (existente) {
      if (existente.quantidade >= produto.estoque) { return false; }
      existente.quantidade++;
    } else {
      if (produto.estoque < 1) { return false; }
      lista.push({ produto, quantidade: 1 });
    }
    this.salvar(lista);
    return true;
  }

  alterarQuantidade(id: number, delta: number): void {
    const lista = this.itens$.value
      .map(i => i.produto.id === id
        ? { ...i, quantidade: Math.min(i.produto.estoque, i.quantidade + delta) }
        : i)
      .filter(i => i.quantidade > 0);
    this.salvar(lista);
  }

  remover(id: number): void {
    this.salvar(this.itens$.value.filter(i => i.produto.id !== id));
  }

  limpar(): void {
    this.salvar([]);
  }

  private salvar(lista: ItemCarrinho[]): void {
    this.itens$.next(lista);
    try { localStorage.setItem(CHAVE, JSON.stringify(lista)); } catch { /* armazenamento indisponível */ }
  }

  private carregar(): ItemCarrinho[] {
    try {
      const bruto = localStorage.getItem(CHAVE);
      return bruto ? JSON.parse(bruto) as ItemCarrinho[] : [];
    } catch { return []; }
  }
}
