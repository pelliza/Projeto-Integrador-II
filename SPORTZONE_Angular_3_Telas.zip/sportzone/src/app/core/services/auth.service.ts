import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Sessao, Usuario } from '../models/produto';

const CHAVE_USUARIOS = 'sz_usuarios';
const CHAVE_SESSAO = 'sz_sessao';

/**
 * Autenticação DEMONSTRATIVA.
 * Não existe servidor: os usuários ficam no localStorage do navegador e a senha é
 * guardada como hash SHA-256 apenas para não aparecer em texto puro. Isto NÃO é um
 * sistema de autenticação seguro e será substituído pelo back-end nas próximas etapas.
 */
@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly sessao$ = new BehaviorSubject<Sessao | null>(this.lerSessao());
  readonly sessao = this.sessao$.asObservable();

  /** Conta de demonstração para testar o login sem cadastrar. */
  readonly contaDemo = { email: 'demo@sportzone.com', senha: 'Demo@1234' };

  async cadastrar(nome: string, email: string, senha: string): Promise<{ ok: boolean; erro?: string }> {
    await this.garantirContaDemo();
    const usuarios = this.lerUsuarios();
    const emailNormalizado = email.trim().toLowerCase();
    if (usuarios.some(u => u.email === emailNormalizado)) {
      return { ok: false, erro: 'Já existe uma conta com este e-mail.' };
    }
    usuarios.push({ nome: nome.trim(), email: emailNormalizado, senhaHash: await this.hash(senha) });
    this.gravarUsuarios(usuarios);
    return { ok: true };
  }

  async entrar(email: string, senha: string): Promise<boolean> {
    await this.garantirContaDemo();
    const emailNormalizado = email.trim().toLowerCase();
    const senhaHash = await this.hash(senha);
    const usuario = this.lerUsuarios().find(u => u.email === emailNormalizado && u.senhaHash === senhaHash);
    if (!usuario) { return false; }
    const sessao: Sessao = { nome: usuario.nome, email: usuario.email };
    this.sessao$.next(sessao);
    try { localStorage.setItem(CHAVE_SESSAO, JSON.stringify(sessao)); } catch { /* ignora */ }
    return true;
  }

  sair(): void {
    this.sessao$.next(null);
    try { localStorage.removeItem(CHAVE_SESSAO); } catch { /* ignora */ }
  }

  private async garantirContaDemo(): Promise<void> {
    const usuarios = this.lerUsuarios();
    if (!usuarios.some(u => u.email === this.contaDemo.email)) {
      usuarios.push({ nome: 'Cliente Demonstração', email: this.contaDemo.email, senhaHash: await this.hash(this.contaDemo.senha) });
      this.gravarUsuarios(usuarios);
    }
  }

  private async hash(texto: string): Promise<string> {
    const dados = new TextEncoder().encode('sportzone:' + texto);
    const buf = await crypto.subtle.digest('SHA-256', dados);
    return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, '0')).join('');
  }

  private lerUsuarios(): Usuario[] {
    try { return JSON.parse(localStorage.getItem(CHAVE_USUARIOS) ?? '[]') as Usuario[]; } catch { return []; }
  }

  private gravarUsuarios(lista: Usuario[]): void {
    try { localStorage.setItem(CHAVE_USUARIOS, JSON.stringify(lista)); } catch { /* ignora */ }
  }

  private lerSessao(): Sessao | null {
    try { return JSON.parse(localStorage.getItem(CHAVE_SESSAO) ?? 'null') as Sessao | null; } catch { return null; }
  }
}
