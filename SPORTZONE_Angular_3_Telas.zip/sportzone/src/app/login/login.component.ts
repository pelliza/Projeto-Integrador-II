import { Component } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from '../core/services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  form = this.fb.nonNullable.group({
    email: ['', [Validators.required, Validators.email]],
    senha: ['', [Validators.required, Validators.minLength(6)]]
  });
  mostrarSenha = false;
  enviando = false;
  erro = '';
  cadastroConcluido = this.route.snapshot.queryParamMap.get('cadastro') === 'ok';

  constructor(
    private fb: FormBuilder,
    private auth: AuthService,
    private router: Router,
    private route: ActivatedRoute
  ) {
    const email = this.route.snapshot.queryParamMap.get('email');
    if (email) { this.form.patchValue({ email }); }
  }

  get email() { return this.form.controls.email; }
  get senha() { return this.form.controls.senha; }

  invalido(c: { invalid: boolean; touched: boolean }): boolean {
    return c.invalid && c.touched;
  }

  usarContaDemo(): void {
    this.form.setValue({ email: this.auth.contaDemo.email, senha: this.auth.contaDemo.senha });
    this.erro = '';
  }

  async entrar(): Promise<void> {
    this.erro = '';
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    this.enviando = true;
    const { email, senha } = this.form.getRawValue();
    const ok = await this.auth.entrar(email, senha);
    this.enviando = false;
    if (ok) {
      this.router.navigate(['/']);
    } else {
      this.erro = 'E-mail ou senha incorretos. Verifique os dados e tente novamente.';
    }
  }
}
